﻿using System.Reflection;

[assembly:AssemblyTitle("Junior.Mapping.UnitTests")]